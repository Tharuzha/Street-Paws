<?php
	$petName = $_POST['petName'];
	$petAge = $_POST['petAge'];
	$vaccinated = $_POST['vaccinated'];
	$trained = $_POST['trained'];
	$color = $_POST['color'];
	$location = $_POST['location'];
	$email = $_POST['email'];
	$number = $_POST['number'];
	$description = $_POST['description'];

	// Database connection
	$conn = new mysqli('localhost','root','','donation');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(petName, petAge, vaccinated, trained, color, location, email, number, description) values(?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sisssssis", $petName, $petAge, $vaccinated, $trained, $color, $location, $email, $number, $description);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>